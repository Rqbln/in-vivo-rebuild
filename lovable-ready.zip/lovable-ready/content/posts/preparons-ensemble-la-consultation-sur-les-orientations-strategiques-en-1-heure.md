---
title: "Préparons ensemble la consultation sur les orientations stratégiques en 1 heure"
date: 2025-11-01T18:22:57.394Z
author: "Philippe Quériaux"
category: "Non classé"
slug: preparons-ensemble-la-consultation-sur-les-orientations-strategiques-en-1-heure
excerpt: ""
featured_image: ""
---

Les élus doivent se préparer,pour bien défendre les intérêts des salariés, et **rendre un avis motivé**.

*   Quels documents doit-on recevoir ?
*   Combien de temps avons-nous pour les étudier ?
*   quelles sont les questions qu'il faut se poser ?
*   Assistance possible d'un l'expert ? (qui paye ? ...)

Nous vous proposons gratuitement  
le 17 janvier prochain de 9h à 10 h  
un échange en visioconférence avec un expert comptable  
afin de vous éclairer sur cette consultation

inscrivez-vous directement en envoyant un mail à  
[consultstrat@in-vivo-expert.fr](mailto:consultstrat@in-vivo-expert.fr),  
pour recevoir le lien

Bien à vous,  
Philippe QUERIAUX
