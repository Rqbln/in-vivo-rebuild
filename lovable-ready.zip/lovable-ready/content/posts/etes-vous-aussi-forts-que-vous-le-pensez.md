---
title: "Êtes-vous aussi forts que vous le pensez ?"
date: 2025-11-01T18:22:57.401Z
author: "Philippe Quériaux"
category: "Non classé"
slug: etes-vous-aussi-forts-que-vous-le-pensez
excerpt: ""
featured_image: ""
---

  
  
Quelques questions simples devront vous aiguiller :

*   Comment est orientée votre activité sur les 5 dernières années ? Est-ce à l’image de ce qui est constaté chez vos concurrents ? sinon, pourquoi ?
*   Quel est l’évolution du taux de profitabilité de votre entreprise, une fois retraités les liens avec le groupe. Est-ce à l’image de ce qui est constaté chez vos concurrents ? sinon, pourquoi ?
*   Quelle est l’évolution de la productivité des salariés de l’entreprise ? et du rapport entre les frais de personnel et le chiffre d’affaires ? Est-ce à l’image de ce que font vos concurrents ? sinon, pourquoi ?

Si vous n’avez pas pu apporter des réponses précises à ces questions simples qui doivent vous permettre de vous situer sur l’échiquier économique et social de votre secteur d’activité, vous pouvez toujours vous appuyer sur la Loi.

En effet, depuis 35 ans, le CSE peut [demander à un expert-comptable indépendant de l’entreprise (payé par la Direction), de lui expliquer de façon pédagogique dans quel état est votre employeur](http://www.in-vivo-expert.fr/examen-des-comptes-annuels.html).

Le réel dialogue social doit reposer sur ces bases solides. Si vous le souhaitez, nous pouvons vous apporter cette assistance. Contactez-nous au 01 75 43 80 80.
