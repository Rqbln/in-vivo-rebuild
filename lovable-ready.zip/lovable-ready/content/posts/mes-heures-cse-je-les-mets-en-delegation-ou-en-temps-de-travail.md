---
title: "Mes heures CSE, je les mets en délégation ou en temps de travail ?"
date: 2025-11-01T18:22:57.401Z
author: "Philippe Quériaux"
category: "Non classé"
slug: mes-heures-cse-je-les-mets-en-delegation-ou-en-temps-de-travail
excerpt: ""
featured_image: ""
---

  
  
**1- Les réunions plénières de CSE, c'est du temps de travail effectif**  
\- Ces temps ne sont pas décomptés du crédit d'heures mensuel  
\- Le temps passé par le Secrétaire du CSE à rédiger le PV du CSE est lui imputé sur le crédit d'heures mensuel  
\- si le membre du CSE vient assister à une réunion pendant ses congés, il doit pouvoir récupérer (ou être indemnisé pour) ce temps de congés dont il n'a pas pu bénéficier.  
  
  
  
**2- Les commissions, ça peut être du temps de travail**  
\- Le temps passé dans les commissions obligatoires, dans les entreprises de plus de 300 salariés (SSCT, formation, logement, égalité professionnelle), ou de plus de 1000 salariés (économique en plus), n'est pas déduit des heures de délégation s'il n'excède pas 30h (ou 60h si plus de 1000 salariés) : c'est alors du temps de travail.  
\- Les commissions SSCT & économiques, résultant d'une obligation d'ordre public et/ou présidées par l'employeur, sont toujours considérées comme du temps de travail  
\- Un accord d'entreprise peut prévoir des modalités différentes, notamment pour les commissions facultatives qui peuvent être mises en place, quelle que soit la taille de l'entreprise.  
  
  
  
**3- Les réunions préparatoires, c'est imputé sur le crédit d'heures mensuel**  
\- les suppléants participent sur leur temps de travail  
\- souvent, ces réunions sont faites à l'heure du déjeuner, ce qui permet à tous d'y participer  
\- un accord d'entreprise peut prévoir des modalités plus favorables, voire une mutualisation entre titulaires et suppléants.  
  
  
Besoin d'explications complémentaires ? appelez-nous au 01 75 43 80 80.
