---
title: "Restez ouverts, même quand la porte est fermée !"
date: 2025-11-01T18:22:57.400Z
author: "Philippe Quériaux"
category: "Non classé"
slug: restez-ouverts-meme-quand-la-porte-est-fermee
excerpt: ""
featured_image: ""
---

En fait, dans toute négociation, la clé est de connaître la marge de négociation de la partie adverse.

Et pour la connaître, il faut vous appuyer sur les possibilités que vous offre la Loi : [L’assistance par un expert-comptable indépendant, choisi par le CSE, et rémunéré par la Direction](http://www.in-vivo-expert.fr/examen-des-comptes-annuels.html).

Lui seul pourra, dans le cadre de ses 3 missions annuelles récurrentes ([examen de la situation économique et financière](http://www.in-vivo-expert.fr/examen-des-comptes-annuels.html), [de la politique sociale](http://www.in-vivo-expert.fr/examen-des-comptes-previsionnels.html), et [des orientations stratégiques](http://www.in-vivo-expert.fr/examen-des-orientations-strategiques.html)), vous synthétiser les marges de manœuvre de votre Direction et de votre actionnaire.

Les négociations se préparent donc bien en amont :

*   Votre expert-comptable devra vous présenter la réalité économique financière et sociale de votre entreprise.
*   Vous formulerez des propositions argumentées à votre Direction, en parfaite connaissance de cause. Être force de proposition sera également valorisant.
*   Votre interlocuteur ne pourra dès lors pas nier des évidences. S’il s’y risque, il se décrédibilise. Au pire, son motif réel de refus sera donc connu de tous, et chacun en tirera les conséquences pour son futur au sein de l’entreprise.

Si vous souhaitez mener à bien vos négociations, nous serons là pour vous aider. Contactez-nous au 01 75 43 80 80.
